package com.mekpap.mekPap

object AppConstants{
    const  val REQUESTID ="REQUESTID"
    const val MECHANICID = "MECHANICID"
    const val NOTIFICATIONSUFFIX = "com.mekpap.mekpap"
}