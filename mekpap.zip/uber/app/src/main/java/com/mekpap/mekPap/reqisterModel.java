package com.smart.mekPap;

public class reqisterModel {
    public String User_name, email,  phone;

    public reqisterModel() {
    }

    public reqisterModel(String user_name, String email, String phone) {
        User_name = user_name;
        this.email = email;
        this.phone = phone;
    }
}
