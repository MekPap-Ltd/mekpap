package com.smart.mekPap.support;

public class UserDetails {
    public static String username = "";
    public static String password = "";
   static String chatWith = "";
}
